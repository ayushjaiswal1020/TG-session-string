# TG-String-Session
Generate String Session Using this bot.

## Configs:
- API_HASH
  - Get from [Here](https://my.telegram.org).
- API_ID
  - Get from [Here](https://my.telegram.org).
- API_KEY
  - Heroku API Key from [Here](https://dashboard.heroku.com/account).
- APP_NAME
  - Heroku App Name.
- BOT_TOKEN
  - Telegram Bot Token from [here](https://t.me/BotFather).

## Deploy Now:
[![Deploy](https://www.herokucdn.com/deploy/button.svg)](https://heroku.com/deploy?template=https://github.com/CyberBoyAyush/TG-String-Session)

## Support Channel:
<a href="https://t.me/AyushBots"><img src="https://img.shields.io/badge/Telegram-Join%20Telegram%20Group-blue.svg?logo=telegram"></a>

#### Credits
- [Krishna Singhal](https://github.com/Krishna-Singhal) For Making Genstr Repo

## Follow on:
<p align="left">
<a href="https://telegram.me/AyushBots"><img src="https://img.shields.io/badge/Join%20Our%20Channel-Ayush%20Bots-darkblue?logo=telegram"></a>
</p>
<p align="left">
<a href="https://github.com/CyberBoyAyush"><img src="https://img.shields.io/badge/GitHub-Follow%20on%20GitHub-inactive.svg?logo=github"></a>
</p>
<p align="left">
<a href="https://twitter.com/CyberBoyAyush"><img src="https://img.shields.io/badge/Twitter-Follow%20on%20Twitter-informational.svg?logo=twitter"></a>
</p>
<p align="left">
<a href="https://instagram.com/CyberBoyAyush"><img src="https://img.shields.io/badge/Instagram-CyberBoyAyush-magenta?logo=instagram"></a>
</p>

## Donate:
[![Donate](https://img.shields.io/badge/Donate%20Us-UPI-orange?style=for-the-badge)](https://upayi.me/ayushsharma.fam@idfcbank)
